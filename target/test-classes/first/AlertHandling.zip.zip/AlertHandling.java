package first;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
 
public class AlertHandling {
 
	public static void main(String[] args) throws InterruptedException {
		
	// Opening the site

	WebDriver driver= new ChromeDriver();
	
	driver.get("https://rediff.com/");
	
	driver.findElement(By.xpath("//a[@class='mailicon']")).click();
	
	driver.manage().window().maximize();
	
	 
	 //sign-in click
	driver.findElement(By.name("proceed")).click();	
	
	Thread.sleep(1000);
	
	 driver.switchTo().alert().accept();
	
	 driver.findElement(By.linkText("Forgot Password?")).click();
	
	 driver.findElement(By.name("next")).click();	
	
	 Alert myalert = driver.switchTo().alert();
	
	 String alertText=myalert.getText();
	 if(alertText.contains("Please enter your email ID"))
	 {
		 System.out.println("correct alert is displayed");
	 }
	 else
	 {
		 System.out.println("wrong alert message is displayed");
	 }
	
	 Thread.sleep(3000);
	 driver.switchTo().alert().accept();
	
	 driver.navigate().back();
	 System.out.println(driver.getCurrentUrl());
	 Thread.sleep(3000);	
	
	 JavascriptExecutor js=(JavascriptExecutor)driver;  
	 js.executeScript("arguments[0].scrollIntoView();",driver.findElement(By.linkText("Privacy Policy")) );
	
	 Thread.sleep(3000);
	 driver.findElement(By.linkText("Privacy Policy")).click();
	
	
	 Thread.sleep(3000);
	  
	 Set<String> windowIDs= driver.getWindowHandles();
	
	List<String> windowList= new ArrayList(windowIDs);
	
	String parentId =windowList.get(0);
	
	String childId =windowList.get(1);
	
	 System.out.println(driver.getTitle());
	 driver.switchTo().window(childId);
	 System.out.println(driver.getTitle());
	
	 driver.close();
	
	 Thread.sleep(3000);
	
	 driver.switchTo().window(parentId);
	 driver.close();
	
	}
 
}